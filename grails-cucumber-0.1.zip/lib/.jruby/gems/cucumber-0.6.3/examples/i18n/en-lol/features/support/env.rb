# encoding: utf-8
require 'cucumber/formatter/unicode'
require 'spec/expectations'

$:.unshift(File.dirname(__FILE__) + '/../../lib')
require 'basket'
require 'belly'
