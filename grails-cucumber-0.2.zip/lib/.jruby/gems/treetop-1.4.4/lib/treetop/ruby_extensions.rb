dir = File.dirname(__FILE__)
require "#{dir}/ruby_extensions/string"