dir = File.dirname(__FILE__)
require "#{dir}/interval_skip_list/interval_skip_list.rb"
require "#{dir}/interval_skip_list/head_node.rb"
require "#{dir}/interval_skip_list/node.rb"