require File.expand_path(File.dirname(__FILE__) + '/../../spec_helper')
require 'yaml'

module Cucumber
module Cli
  describe ProfileLoader do
    it "should have all of its specs migrated from configuration_spec"
  end
end
end
