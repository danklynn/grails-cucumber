# encoding: utf-8
require 'spec/expectations'
require 'cucumber/formatter/unicode'

$:.unshift(File.dirname(__FILE__) + '/../../lib') 
require 'kalkulator'
